﻿using Activity3.Models;
using Activity3.Services.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Activity3.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View("Login");
        }

        [HttpPost]
        public ActionResult Login(UserModel user)
        {
            SecurityService securityService = new SecurityService();
            Boolean success = securityService.Authenticate(user);

            if(success)
            {
                return View("LoginSuccess", user);
            }
            else
            {
                return View("LoginFail");
            }
        }
    }
}